import axiosSecure from "../api/axiosSecure";

export const getVendorAssignments = (page = 1) =>
  axiosSecure.get(`/vendor-assignments?page=${page}`);

export const createVendorAssignment = (data) =>
  axiosSecure.post("/vendor-assignments", data);

export const updateVendorAssignment = (id, data) =>
  axiosSecure.put(`/vendor-assignments/${id}`, data);
