import { createContext, useContext, useState, useEffect } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(
        localStorage.getItem("isLoggedIn") === "true"
    );

    const login = (email, password) => {
        // Simulated login logic
        localStorage.setItem("isLoggedIn", "true");
        setIsAuthenticated(true);
        return true;
    };

    const logout = () => {
        localStorage.removeItem("isLoggedIn");
        setIsAuthenticated(false);
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
